import { Container, Label, version as pcuiVersion, revision as pcuiRevision } from '@playcanvas/pcui';
import { version as engineVersion, revision as engineRevision } from 'playcanvas';

import { version as appVersion } from '../../package.json';

// Inline SVG for the SuperSplat logo
const logoSvg = `
<svg xmlns='http://www.w3.org/2000/svg' width="64" height="64" viewBox='64 64 384 384'>
  <path fill='#f26722' d='M129.83,217c9.75,0,17.64-7.9,17.64-17.64s-7.9-17.64-17.64-17.64-17.64,7.9-17.64,17.64,7.9,17.64,17.64,17.64Z'/>
  <path fill='#f26722' d='M388.74,253.94c-12.46,0-22.57,10.11-22.57,22.57s10.11,22.57,22.57,22.57,22.57-10.11,22.57-22.57-10.11-22.57-22.57-22.57h0Z'/>
  <path fill='#f26722' d='M345.26,161.1h.02c.37-.05.65-.22.97-.33,16.78-2.32,29.75-16.57,29.75-33.99,0-19.04-15.43-34.46-34.46-34.46s-34.46,15.43-34.46,34.46c0,4.29.88,8.35,2.32,12.14.04.12-.01.25.04.38,10.55,29.18-22.33,23.62-39.07,20.74-.49-.09-.88-.07-1.32-.11-4.27-.56-8.59-.97-13.03-.97-53.93,0-97.64,43.71-97.64,97.64,0,9.84,1.48,19.32,4.2,28.28.04.1,0,.17.05.27,8.97,30.15-14.83,25.49-25.52,25.69-1.04-.13-2.09-.32-3.18-.32-13.51,0-24.45,10.94-24.45,24.45s10.94,24.45,24.45,24.45c11.69,0,21.44-8.22,23.85-19.19h.02c6.31-26.57,25.9-18.02,31.15-12.67.2.2.4.26.59.42,17.44,16.25,40.75,26.26,66.47,26.26.67,0,1.34-.09,2.01-.1.66.01,1.31.04,2.04.04,9.7-.04,17.82,10.91,4.94,29.68h.13c-4.42,6.01-7.1,13.36-7.1,21.41,0,20.09,16.29,36.39,36.39,36.39s36.39-16.29,36.39-36.39c0-15.4-9.61-28.49-23.12-33.81-.32-.15-.61-.29-.98-.45-12.28-4.94-25.43-17.69-6.89-27.1l-.04-.1c31.93-16.06,53.88-49.02,53.88-87.2,0-21.15-6.8-40.68-18.23-56.66-.13-.23-.23-.47-.44-.74-23.15-31.67-2.37-36.07,10.3-38.09h-.01Z'/>
  <path fill='white' d='M230.79,284.71c0,7.95-6.44,14.38-14.38,14.38s-14.38-6.44-14.38-14.38v-22.95c0-7.95,6.44-14.38,14.38-14.38s14.38,6.44,14.38,14.38v22.95Z'/>
  <path fill='white' d='M309.78,284.71c0,7.95-6.44,14.38-14.38,14.38s-14.38-6.44-14.38-14.38v-22.95c0-7.95,6.44-14.38,14.38-14.38s14.38,6.44,14.38,14.38v22.95Z'/>
</svg>
`;

class AboutPopup extends Container {
    constructor(args = {}) {
        args = {
            ...args,
            id: 'about-popup',
            class: 'blocks-shortcuts',
            hidden: true,
            tabIndex: -1
        };

        super(args);

        // Handle keyboard events
        this.dom.addEventListener('keydown', (e: KeyboardEvent) => {
            if (e.key === 'Escape') {
                this.hidden = true;
            }
            e.stopPropagation();
        });

        // Close when clicking outside dialog
        this.on('click', () => {
            this.hidden = true;
        });

        const dialog = new Container({
            id: 'about-dialog'
        });

        // Prevent clicks inside dialog from closing
        dialog.on('click', (event: MouseEvent) => {
            event.stopPropagation();
        });

        // Header bar
        const header = new Label({
            id: 'about-header',
            text: 'About'
        });

        // Content area
        const content = new Container({
            id: 'about-content'
        });

        // Logo
        const logoContainer = new Container({
            id: 'about-logo'
        });
        logoContainer.dom.innerHTML = logoSvg;
        logoContainer.dom.addEventListener('click', () => {
            window.open('https://github.com/playcanvas/supersplat', '_blank')?.focus();
        });

        // App name and version
        const appInfo = new Container({
            id: 'about-app-info'
        });
        appInfo.dom.addEventListener('click', () => {
            window.open('https://github.com/playcanvas/supersplat', '_blank')?.focus();
        });

        const appName = new Label({
            id: 'about-app-name',
            text: 'SuperSplat'
        });

        const appVersionLabel = new Label({
            id: 'about-app-version',
            text: `v${appVersion}`
        });

        appInfo.append(appName);
        appInfo.append(appVersionLabel);

        // Dependencies
        const depsContainer = new Container({
            id: 'about-deps'
        });

        // PCUI
        const pcuiRow = new Container({
            class: 'about-dep-row'
        });
        pcuiRow.dom.addEventListener('click', () => {
            window.open('https://github.com/playcanvas/pcui', '_blank')?.focus();
        });
        const pcuiName = new Label({ class: 'about-dep-name', text: 'PCUI' });
        const pcuiVersionL = new Label({ class: 'about-dep-version', text: `v${pcuiVersion}` });
        const pcuiRev = new Label({ class: 'about-dep-revision', text: `(${pcuiRevision.substring(0, 7)})` });
        pcuiRow.append(pcuiName);
        pcuiRow.append(pcuiVersionL);
        pcuiRow.append(pcuiRev);

        // Engine
        const engineRow = new Container({
            class: 'about-dep-row'
        });
        engineRow.dom.addEventListener('click', () => {
            window.open('https://github.com/playcanvas/engine', '_blank')?.focus();
        });
        const engineName = new Label({ class: 'about-dep-name', text: 'PlayCanvas' });
        const engineVer = new Label({ class: 'about-dep-version', text: `v${engineVersion}` });
        const engineRev = new Label({ class: 'about-dep-revision', text: `(${engineRevision.substring(0, 7)})` });
        engineRow.append(engineName);
        engineRow.append(engineVer);
        engineRow.append(engineRev);

        depsContainer.append(pcuiRow);
        depsContainer.append(engineRow);

        // Assemble content
        content.append(logoContainer);
        content.append(appInfo);
        content.append(depsContainer);

        // Assemble dialog
        dialog.append(header);
        dialog.append(content);

        this.append(dialog);

        // Focus when shown so keyboard events work
        this.on('show', () => {
            this.dom.focus();
        });
    }
}

export { AboutPopup };
