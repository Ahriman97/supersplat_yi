import { Button, Container, Label, SelectInput, TextInput } from '@playcanvas/pcui';

import { i18n } from './localization';
import { Tooltips } from './tooltips';

interface ShowOptions {
    type: 'error' | 'info' | 'yesno' | 'okcancel';
    message: string;
    header?: string;
    link?: string;
    icon?: boolean;     // show the type icon before the message (default true)
    select?: {
        options: { v: string, t: string }[];
        value: string;
    };
    warning?: {         // secondary note below the select
        text: string;
        link?: string;  // optional link rendered inline after the text
    };
}

type ShowResult = {
    action: string;
    value?: string;
};

class Popup extends Container {
    show: (options: ShowOptions) => Promise<ShowResult>;
    hide: () => void;
    destroy: () => void;

    constructor(tooltips: Tooltips, args = {}) {
        args = {
            id: 'popup',
            class: 'blocks-shortcuts',
            hidden: true,
            tabIndex: -1,
            ...args
        };

        super(args);

        const dialog = new Container({
            id: 'popup-dialog'
        });

        const header = new Label({
            id: 'popup-header'
        });

        const text = new Label({
            id: 'popup-text'
        });

        const linkText = new Label({
            id: 'popup-link-text'
        });

        const linkCopy = new Button({
            id: 'popup-link-copy',
            icon: 'E351'
        });

        const linkRow = new Container({
            id: 'popup-link-row'
        });

        linkRow.append(linkText);
        linkRow.append(linkCopy);

        const selectInput = new SelectInput({
            id: 'popup-select'
        });

        const selectRow = new Container({
            id: 'popup-select-row'
        });

        selectRow.append(selectInput);

        const warningText = new Label({
            id: 'popup-warning-text'
        });

        const okButton = new Button({
            class: 'popup-button'
        });
        i18n.bindText(okButton, 'popup.ok');

        const cancelButton = new Button({
            class: 'popup-button'
        });
        i18n.bindText(cancelButton, 'popup.cancel');

        const yesButton = new Button({
            class: 'popup-button'
        });
        i18n.bindText(yesButton, 'popup.yes');

        const noButton = new Button({
            class: 'popup-button'
        });
        i18n.bindText(noButton, 'popup.no');

        const buttons = new Container({
            id: 'popup-buttons'
        });

        buttons.append(okButton);
        buttons.append(cancelButton);
        buttons.append(yesButton);
        buttons.append(noButton);

        dialog.append(header);
        dialog.append(text);
        dialog.append(selectRow);
        dialog.append(warningText);
        dialog.append(linkRow);
        dialog.append(buttons);

        this.append(dialog);

        let okFn: () => void;
        let cancelFn: () => void;
        let yesFn: () => void;
        let noFn: () => void;
        let containerFn: () => void;
        let copyFn: () => void;

        okButton.on('click', () => {
            okFn();
        });

        cancelButton.on('click', () => {
            cancelFn();
        });

        yesButton.on('click', () => {
            yesFn();
        });

        noButton.on('click', () => {
            noFn();
        });

        this.on('click', () => {
            containerFn();
        });

        dialog.on('click', (event) => {
            event.stopPropagation();
        });

        linkCopy.on('click', () => {
            copyFn();
        });

        this.show = (options: ShowOptions) => {
            header.text = options.header;
            text.text = options.message;

            const { type, link, select, warning } = options;

            ['error', 'info', 'yesno', 'okcancel'].forEach((t) => {
                text.class[t === type && options.icon !== false ? 'add' : 'remove'](t);
            });

            // configure based on message type
            okButton.hidden = type === 'yesno';
            cancelButton.hidden = type !== 'okcancel';
            yesButton.hidden = type !== 'yesno';
            noButton.hidden = type !== 'yesno';
            this.hidden = false;

            linkRow.hidden = link === undefined;
            if (link !== undefined) {
                linkText.dom.innerHTML = `<a href='${link}' target='_blank'>${link}</a>`;
                linkCopy.icon = 'E352';
            }

            // the select dropdown list renders outside the dialog bounds
            dialog.class[select ? 'add' : 'remove']('has-select');
            selectRow.hidden = select === undefined;
            if (select !== undefined) {
                selectInput.options = select.options;
                selectInput.value = select.value;
            }

            warningText.hidden = warning === undefined;
            warningText.dom.textContent = warning?.text ?? '';
            if (warning?.link) {
                const anchor = document.createElement('a');
                anchor.href = warning.link;
                anchor.target = '_blank';
                anchor.rel = 'noopener noreferrer';
                anchor.textContent = warning.link;
                warningText.dom.append(' ', anchor);
            }

            // take keyboard focus so shortcuts stop working
            this.dom.focus();

            return new Promise<ShowResult>((resolve) => {
                okFn = () => {
                    this.hide();
                    resolve({
                        action: 'ok',
                        value: select ? selectInput.value : undefined
                    });
                };
                cancelFn = () => {
                    this.hide();
                    resolve({ action: 'cancel' });
                };
                yesFn = () => {
                    this.hide();
                    resolve({ action: 'yes' });
                };
                noFn = () => {
                    this.hide();
                    resolve({ action: 'no' });
                };
                containerFn = () => {
                    if (type === 'info' && link === undefined) {
                        cancelFn();
                    }
                };
                copyFn = () => {
                    navigator.clipboard.writeText(link);
                    linkCopy.icon = 'E348';
                };
            });
        };

        this.hide = () => {
            this.hidden = true;
        };

        this.destroy = () => {
            this.hide();
            super.destroy();
        };

        tooltips.register(linkCopy, () => i18n.t('popup.copy-to-clipboard'));
    }
}

export { ShowOptions, Popup };
